package co.mod12.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class MobileDAOImpl implements MobilePhoneDAO {

	private JdbcTemplate jdtemp;

	public JdbcTemplate getJdtemp() {
		return jdtemp;
	}
	public void setJdtemp(JdbcTemplate jdtemp) {
		this.jdtemp = jdtemp;
	}


	@Override
	public void savePhone(MobilePhone mobile) {

		String insql = "insert into mobiles values('"+mobile.getManufacturerName()+"',"+mobile.getPhonePrice()+",'"+mobile.getPhoneColor()+"')";
		int row = jdtemp.update(insql);
		if (row>0)
		{
			System.out.println("Mobile information saved successfully!!");
		}

	}
	@Override
	public void updatePhone(MobilePhone mobile) {

		String upsql = "update mobiles set manufacturer_name ='"+mobile.getManufacturerName()+"',phone_price="+mobile.getPhonePrice()+",phone_color='"+mobile.getPhoneColor()+"')";
		int row = jdtemp.update(upsql);
		if(row>0) {
			System.out.println("Mobile information updated successfully!!");
		}
	}
	@Override
	public void deletePhone(String manufacturerName) {

		String delsql = "delete from mobiles where manufacturer_name= '"+manufacturerName+"'";
		int row = jdtemp.update(delsql);
		if (row>0)
		{
			System.out.println("Mobile information deleted successfully!!");
		}
	}
	@Override
	public List<MobilePhone> getMobilePhoneslist(){
		String sql = "select * from mobiles";

		List<MobilePhone> l = jdtemp.query(sql, new ResultSetExtractor<List<MobilePhone>>()
		{
			public List<MobilePhone> extractData(ResultSet rs) throws SQLException, DataAccessException {

				List <MobilePhone> phonelist = new ArrayList<MobilePhone>();
				while(rs.next())
				{
					MobilePhone mp = new MobilePhone();
					mp.setManufacturerName(rs.getString(1));
					mp.setPhonePrice(rs.getFloat(2));
					mp.setPhoneColor(rs.getString(3));
					phonelist.add(mp);					
				}
				
				return phonelist;
				
			}
		});
		return l;

	}


}



