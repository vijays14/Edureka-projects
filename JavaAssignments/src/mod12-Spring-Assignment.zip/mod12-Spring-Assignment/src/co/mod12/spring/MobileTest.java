package co.mod12.spring;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MobileTest {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		
		MobilePhoneDAO mp = (MobilePhoneDAO)context.getBean("mobiledao");
		
	
		String ans = "Y";
		Scanner sc = new Scanner(System.in);
		
		while(ans.equalsIgnoreCase("Y"))
		{
		System.out.println("Enter MobilePhone information : ");
		
		System.out.print("Enter Mobile Manufacturer Name : ");
		String name = sc.next();
		System.out.print("Enter Mobile Phone Price in Rs.: ");
		float price = sc.nextFloat();
		System.out.print("Enter Mobile Phone color : ");
		String col = sc.next();
		
		MobilePhone phone1 = new MobilePhone(name,price,col);
		
		mp.savePhone(phone1);
		System.out.print("Do you wish to enter more Mobile information ? Y/N ? ");
		ans = sc.next();
		}
		List<MobilePhone> phones = mp.getMobilePhoneslist();
		for(MobilePhone mobile : phones)
		{
			System.out.println(mobile);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}
	}

}
