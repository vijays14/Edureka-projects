package co.mod12.spring;

import java.util.List;

public interface MobilePhoneDAO {
	
	
	public void savePhone(MobilePhone mobile);
	public void updatePhone(MobilePhone mobile);
	public void deletePhone(String manufacturerName);
	public List<MobilePhone> getMobilePhoneslist();

}
