package co.mod12.spring;

public class MobilePhone {
	
	private String manufacturerName;
	private Float phonePrice;
	private String phoneColor;
	
	public MobilePhone() {
		
	}
	public MobilePhone(String manufacturerName, Float phonePrice, String phoneColor) {
		super();
		this.manufacturerName = manufacturerName;
		this.phonePrice = phonePrice;
		this.phoneColor = phoneColor;
	}
	public String getManufacturerName() {
		return manufacturerName;
	}
	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}
	public Float getPhonePrice() {
		return phonePrice;
	}
	public void setPhonePrice(Float phonePrice) {
		this.phonePrice = phonePrice;
	}
	public String getPhoneColor() {
		return phoneColor;
	}
	public void setPhoneColor(String phoneColor) {
		this.phoneColor = phoneColor;
	}
	@Override
	public String toString() {
		return "Mobile_Phone info : Phone_Name= " + manufacturerName + " || Phone_Price=" + phonePrice + "||  Phone_Color="
				+ phoneColor ;
	}
	
	
	

}
