package mod11.spring.hibernate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		
		EmployeeDAO employee =(EmployeeDAO)context.getBean("empdao");
						
		employee.salEmp("John marquee");
		
		
	}

}
