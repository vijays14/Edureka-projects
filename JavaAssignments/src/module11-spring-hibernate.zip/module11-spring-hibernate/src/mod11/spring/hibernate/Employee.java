package mod11.spring.hibernate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.*;

@Entity
@Table(name = "EMPLOYEE")

public class Employee {
	
	@Id 
	private int Id;

	@Column(name = "Name")
	private String name;

	@Column(name = "Basic")
	private float basic;
	@Column(name = "HRA")
	private float hra;
	@Column(name = "DA")
	private float da;
	@Column(name = "Deductions")
	private float deductions;

	public Employee() {
	}
	public Employee(int id, String name, float basic, float hra, float da, float deductions) {
		super();
		this.Id = id;
		this.name = name;
		this.basic = basic;
		this.hra = hra;
		this.da = da;
		this.deductions = deductions;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBasic() {
		return basic;
	}
	public void setBasic(float basic) {
		this.basic = basic;
	}
	public float getHra() {
		return hra;
	}
	public void setHra(float hra) {
		this.hra = hra;
	}
	public float getDa() {
		return da;
	}
	public void setDa(float da) {
		this.da = da;
	}
	public float getDeductions() {
		return deductions;
	}
	public void setDeductions(float deductions) {
		this.deductions = deductions;
	}
	
	@Override
	public String toString() {
		return "Employee Details : Id=" + Id + "|| Name=" + name + "|| Basic=" + basic + "|| HRA=" + hra + "|| DA=" + da
				+ "|| Deductions=" + deductions;
	}



}
