package mod11.spring.hibernate;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class EmployeeDAO {
	
	private HibernateTemplate ht;

	public HibernateTemplate getHt() {
		return ht;
	}

	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	@Transactional(readOnly=false)
	public void addEmp(Employee emp)
	{
		ht.save(emp);
		
		System.out.println("Employee added successfully!!");
	}
	
	
	public Employee searchEmp(String name)
	{
		
		Session session;

		try {
		    session = ht.getSessionFactory().getCurrentSession();
		} catch (HibernateException e) {
		    session = ht.getSessionFactory().openSession();
		} 
		Query query = session.createQuery("FROM Employee where name=:name");
		query.setString("name", name);		
		
		List<Employee> emplist = query.list();
		 
		return emplist.get(0);
	}

	
	public void salEmp(String name)
	{
		Employee emp = searchEmp(name);
		System.out.println(emp);
		float netSal;
		
		float grossSal = emp.getBasic()+emp.getHra()+emp.getDa();
		float tax  = grossSal*(0.15f);
		
		netSal = grossSal -(tax + emp.getDeductions());
		
		System.out.println("Net Salary of Employee - "+ name + " : $"+netSal);
		
	}
	
}
