package co.servlet.assignment;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

	}			

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get html form data

		String uid=request.getParameter("username");
		String pwd=request.getParameter("password");
		
		try
		{
if ((uid != null) && (pwd != null))
{
			Cookie unamecookie = new Cookie("username",uid);
			Cookie pwdcookie = new Cookie("password",pwd);
			//set 30 days expiry for username
			unamecookie.setMaxAge(60*60*24*30);

			response.addCookie(unamecookie);
			response.addCookie(pwdcookie);
			System.out.println("Checking : "+unamecookie.getName());


			//for the valid username and pwd, forward the request to Admin page
			RequestDispatcher rd = request.getRequestDispatcher("admin");
			rd.forward(request, response);
}
else 
{
	System.out.println("Unable to get the Store Cookies!!");
}
		}catch (Exception e)
		{
			e.printStackTrace();
		}


	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}
	@Override
	public void destroy() {
		System.out.println("Closing all the Connections.");
	}

}
