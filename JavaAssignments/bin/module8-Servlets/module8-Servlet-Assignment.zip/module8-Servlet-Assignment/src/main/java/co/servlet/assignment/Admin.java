package co.servlet.assignment;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Sudha Vijayakumar
 * Module 8 - Servlet Assignments-Login Application
 * 
 */
@WebServlet("/admin")
public class Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body style=background-image:url(images/oceanimage.jpg);background-size:cover;>");

		out.println("<h1 style=color:coral;text-align:center>Swimmer Profile</h1>");
		out.println("<h4 style=color:coral;font-size:25px;text-align:center>User Account Settings</h4>");
		out.println("<p style=font-size:22px;color:cyan >Welcome !! "+request.getParameter("username").toUpperCase()+"!!"+"</p><br>");
		out.println("<p style=font-size:22px;color:cyan >Account details:-</p>");
		out.println("<p style=font-size:22px;color:cyan >UserName : "+request.getParameter("username")+"</p>");
		out.println("<p style=font-size:22px;color:cyan >Password : "+request.getParameter("password")+"</p>");
		
		//Printing cookies on the main page - to show that cookies have reached main page

		out.println("<p style=font-size:20px;color:yellow>Printing Cookies:-</p>");
		Cookie []cookies = request.getCookies();
		if (cookies != null){
			
		for(Cookie cooky:cookies)
		{
			String name = cooky.getName();
			String value = cooky.getValue();
			out.println("<p style=font-size:15px;color:yellow > Name | Value: "+ name +" - "+ value +"</p>");
		}
		}
		out.println("</body></html>");
		out.close();

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}

