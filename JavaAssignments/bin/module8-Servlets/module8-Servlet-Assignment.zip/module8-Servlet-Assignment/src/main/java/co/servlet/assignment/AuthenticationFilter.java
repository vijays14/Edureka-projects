package co.servlet.assignment;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
@WebFilter("/login")
public class AuthenticationFilter implements Filter {

	public AuthenticationFilter() {

	}

	public void destroy() {

	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//get the username and password from request
		String uname =request.getParameter("username");
		String passwd = request.getParameter("password");
		if("admin".equals(uname)&& "12345".equals(passwd))
		{
			chain.doFilter(request, response);
		}
		else
		{
			//for the invalid username and password, redirect the request to login page again
			 out.println("<p style=font-size:18px;color:red;text-align:center >Invalid Username/Password combination</p>");
			 RequestDispatcher rd = request.getRequestDispatcher("Login.html");
			 rd.include(request, response);
		}
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}


	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
