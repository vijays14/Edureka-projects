package mod10.assignment.config;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class sessionconfig {

	public static Session newSession() {

		Configuration config = new Configuration().configure("mod10/assignment/config/students.config.xml");

		SessionFactory sessionfactory = config.buildSessionFactory();

		Session newsession = sessionfactory.openSession();

		return newsession;

	}

}
