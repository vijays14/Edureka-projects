package mod10.assignment.application;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import mod10.assignment.bean.Student;
import mod10.assignment.config.sessionconfig;

public class StudentApplication {

	// Display Student list
	public static List getlist() {

		List<Student> studentlist = null;
		try {

			Session session = sessionconfig.newSession();
			studentlist = session.createQuery("from Student order by MARKS desc", Student.class).list();
			session.close();

		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}

		return studentlist;
	}

	// Inserting Students to the DB

	public static String inStudent(Student st) {
		Transaction tx = null;

		try {
			Session session = sessionconfig.newSession();
			tx = session.beginTransaction();
			String name = st.getStudentName();
			Integer mark = st.getMarks();
			st = new Student(name, mark);
			// save the new student data into database
			session.save(st);

			tx.commit();
			session.close();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}

		}
		System.out.println("Student '" + st.getStudentName() + "' saved Successfully!!");
		return st.getStudentName();

	}

	// Deleting students from DB
	public static boolean deleteStudent(String studentName) {
		boolean type = false;
		Transaction tx = null;
		try {
			Session session = sessionconfig.newSession();
			Student student = findStudent(studentName);
			Integer mark = student.getMarks();
			tx = session.beginTransaction();

			if (mark < 35) {
				session.delete(student);

				System.out.println("Student '" + studentName + "' deleted from Student Records.");
				type = true;
			} else {
				System.out.println("Student '" + studentName + "' Scored above 35 cannot be deleted.");

			}
			tx.commit();

		} catch (Exception e) {

			if (tx != null) {

				tx.rollback();
				type = false;
			}
			e.printStackTrace();
		}

		return type;
	}

	public static Student updateStudent(Student st) {
		Session session = sessionconfig.newSession();
		String name = st.getStudentName();
		Integer mark = st.getMarks();
		st = new Student(name, mark);
		st = findStudent(name);
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			st.setMarks(mark);
			session.saveOrUpdate(st);
			tx.commit();
		} catch (Exception e) {

			if (tx != null) {

				tx.rollback();
			}
			e.printStackTrace();
		}

		return (st);
	}

	// find student record based on name
	public static Student findStudent(String sName) {
		Session session = sessionconfig.newSession();
		String hql = "FROM Student WHERE name = :name";
		Query query = session.createQuery(hql).setParameter("name", sName);
		List<Student> studentlist = query.list();

		for (Student students : studentlist) {
			System.out.println(students);
		}

		return studentlist.get(0);
	}

}
